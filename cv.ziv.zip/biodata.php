<html>
<head>
<title>Membuat Biodata Sederhana</title>
</head>
<body>
<form action="#" style="width: 700px"class="posisi";>
<fieldset class="h"/>
<table style="width: 600px;">
<body style="background-color:pink"> </body>

<tr>
<td rowspan="10" width="100px">
<img src="POTOS.jpg" width="150px" height="200px" border="5">
</td>
</tr>
<center>
<font size="25px">
<b>BIODATA</b>
</font>
</center>
<tr>
<td><b>NAMA</b></td>
<td>:   ANNISA NUR EKA PRAMUDITA</td>
</tr>
<tr>
<td><b>NIM</b></td>
<td>:   -</td>
</tr>
<tr>
<td><b>TTL</b></td>
<td>:   Bandung, 14 April 2002</td>
</tr>
<tr>
<td><b>ALAMAT</b></td>
<td>:   Jl tubagus ismail gg menara air 2 no 3</td>
</tr>
<tr>
<td><b>JENIS KELAMIN</b></td>
<td>:   Perempuan</td>
</tr>
<tr>
<td><b>AGAMA</b></td>
<td>:   Islam</td>
</tr>
</body>
</html>